const { spawn } = require('child_process');
const child = spawn('dir', ['D:\\empty'], { shell: true });

child.stdout.on('data', (data) => {
console.log(`stdout ${data}`);
});
